package com.salesianostriana.mario.formbean;

public class SearchBean {
	private String search;
	
	public SearchBean(){
		
	}

	public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}
}
