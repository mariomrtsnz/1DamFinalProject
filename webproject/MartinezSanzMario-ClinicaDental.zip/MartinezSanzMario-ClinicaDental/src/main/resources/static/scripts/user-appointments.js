$(document).ready(function() {
	/*FooTable*/
	jQuery(function($){
		var ft = FooTable.init('.services-list', {}),
		uid = 10001;
	});
});
