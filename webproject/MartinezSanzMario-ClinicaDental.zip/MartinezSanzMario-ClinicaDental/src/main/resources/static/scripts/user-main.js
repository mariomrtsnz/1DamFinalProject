$(document).ready(function() {
	$("#indexHeader, #indexNav").stick_in_parent();
});